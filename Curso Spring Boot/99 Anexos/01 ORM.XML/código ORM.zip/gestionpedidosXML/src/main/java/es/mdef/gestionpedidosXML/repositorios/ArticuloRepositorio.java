package es.mdef.gestionpedidosXML.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import es.mdef.gestionpedidosXML.entidades.Articulo;

public interface ArticuloRepositorio extends JpaRepository<Articulo, Long> {

}
