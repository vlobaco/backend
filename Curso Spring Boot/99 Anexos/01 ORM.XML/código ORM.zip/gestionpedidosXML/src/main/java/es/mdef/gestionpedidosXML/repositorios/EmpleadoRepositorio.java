package es.mdef.gestionpedidosXML.repositorios;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import es.mdef.gestionpedidosXML.entidades.Empleado;

public interface EmpleadoRepositorio extends JpaRepository<Empleado, Long> {
	Optional<Empleado> findByUsername(String username);
}
