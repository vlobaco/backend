package es.mdef.gestionpedidos.entidades;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="empleados")
public class Empleado extends es.mdef.ejemplo001.support.Empleado {
	@Column(unique=true, name = "nombre_usuario")
	private String username;
	@Column(name="contrasena")
	private String password;
	@OneToMany(mappedBy = "empleado")
	private List<Pedido> pedidos;

	public List<Pedido> getPedidos() {
		return pedidos;
	}

	public void setPedidos(List<Pedido> pedidos) {
		this.pedidos = pedidos;
	}
	
	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Empleado [username=" + username + ", password=" + password + "]";
	}
	
}
